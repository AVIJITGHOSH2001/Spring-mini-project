package org.jsp.Demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerAllApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerAllApplication.class, args);
	}

}
