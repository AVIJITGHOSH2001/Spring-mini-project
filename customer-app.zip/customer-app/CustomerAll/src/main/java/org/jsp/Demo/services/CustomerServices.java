package org.jsp.Demo.services;

import org.jsp.Demo.dao.CustomerDao;
import org.jsp.Demo.dto.Customer;
import org.jsp.Demo.dto.ResponseStructure;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class CustomerServices {
	@Autowired
	private CustomerDao dao;
	public ResponseEntity<ResponseStructure<Customer>>saveCustomer(Customer customer)
	{
		ResponseStructure<Customer> structure=new ResponseStructure<>();
		customer=dao.saveCustomer(customer);
		structure.setData(customer);
		structure.setMessage("Customer register successfull with ID="+customer.getId());
		structure.setStatusCode(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<Customer>>(structure,HttpStatus.CREATED);
				
				
				
	}

}
