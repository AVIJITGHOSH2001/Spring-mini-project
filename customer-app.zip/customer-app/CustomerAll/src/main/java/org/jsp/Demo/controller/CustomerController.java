package org.jsp.Demo.controller;

import org.jsp.Demo.dto.Customer;
import org.jsp.Demo.dto.ResponseStructure;
import org.jsp.Demo.services.CustomerServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin
public class CustomerController {
	@Autowired
	private CustomerServices services;
	
	@PostMapping("/customer")
	public ResponseEntity<ResponseStructure<Customer>>saveCustomer(@RequestBody Customer customer)
	{
		return services.saveCustomer(customer);
	}

}
