package org.jsp.Demo.exception;

public class InvalidCredential extends RuntimeException {
	@Override
	public String getMessage() {
		return "Invalid phone or password or id";
	}

}
