package org.jsp.Demo.dao;

import org.jsp.Demo.dto.Customer;
import org.jsp.Demo.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class CustomerDao {
	@Autowired
	private CustomerRepository repository;
	
	public Customer saveCustomer(Customer customer)
	{
		System.out.println(repository);
		return repository.save(customer);
	}

}
