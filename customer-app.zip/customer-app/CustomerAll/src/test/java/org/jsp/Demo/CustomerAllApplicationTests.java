package org.jsp.Demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerAllApplicationTests {

	@Test
	void contextLoads() {
	}

}
