import axios from 'axios';
import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';

function Registration() {
  

  let [fname, setFName] = useState("");
  let [lname, setLName] = useState("");
  let [email, setEmail] = useState("");
  let [pnumber, setPNumber] = useState("");
  let [address, setAddress] = useState("");
  let [city, setCity] = useState("");
  let [state, setState] = useState("");

 let data={fname,lname,address,city,state,email,pnumber}

 const handelSubmit=(e)=>{
    e.preventDefault();
    axios.post(`http://localhost:8080/customer`,data)
    .then((res)=>{
        alert("success")
        console.log(res)
    

    })
    .catch((err)=>{
      alert("invalid data")
       console.log(err)
    })
 }
  return (
    <div className="customer">
      <form>
        <fieldset>
          <legend>Merchant Sign Up</legend>
          <label htmlFor=""> First Name</label>
          <input
            type="text"
            value={fname}
            onChange={(e) => {
              setFName(e.target.value);
            }}
          />
          <label htmlFor=""> Last Name</label>
          <input
            type="text"
            value={lname}
            onChange={(e) => {
              setLName(e.target.value);
            }}
          />
          <label htmlFor=""> Address</label>
          <input
            type="text"
            value={address}
            onChange={(e) => {
              setAddress(e.target.value);
            }}
          />
          <label htmlFor="">Email</label>
          <input
            type="email"
            value={email}
            onChange={(e) => {
              setEmail(e.target.value);
            }}
          />
          <label htmlFor="">Phone</label>
          <input
            pattern="[0-9]{10}"
            type="tel"
            value={pnumber}
            onChange={(e) => {
              setPNumber(e.target.value);
            }}
          />
          
          <label htmlFor="">City</label>
          <input
            type="city"
            value={city}
            onChange={(e) => {
              setCity(e.target.value);
            }}
          />
          <label htmlFor="">State</label>
          <input
            type="state"
            value={state}
            onChange={(e) => {
              setState(e.target.value);
            }}
          />
          <button onClick={handelSubmit}>Register</button>
        </fieldset>
      </form>
    </div>
  )
}

export default Registration