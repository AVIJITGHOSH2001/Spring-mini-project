import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import axios from 'axios'
import { useNavigate } from "react-router-dom";

function Login1() {
  const [email, setEmail]=useState(" ");
  const [password, setPassword]=useState(" ");
    const [errorMessage, setErrorMessage] = useState('');
    let navigate=useNavigate()


    const validEmail = 'abc@gmail.com';
    const validPassword = 'abc@123';

    let login=(e)=>{
      e.preventDefault();
      if (email === validEmail && password === validPassword) {
        alert('Login successful!');
        setErrorMessage('');
        navigate('/registration');
    }
    else {
      // Invalid login, show error message
      setErrorMessage('Invalid email or password');
    }
  }

  return (
    <div>
        <h2>Log In Page</h2>
        <form >
            <input type="email" name='email' value={email} onChange={(e=>{setEmail(e.target.value)})} placeholder='Enter your email' />
            <br/>
            <input type="password" name='password' value={password} onChange={(e=>{setPassword(e.target.value)})} placeholder='Enter your password' />
            <br/>
         <button onClick={login}>Login</button>
         
        </form>
        {errorMessage && <p style={{ color: 'red' }}>{errorMessage}</p>}
        {/* <Link to="/home"> Click to Home</Link> */}
         {/* <Link to="/registration"> Register</Link>  */}

    </div>
  )
}

export default Login1